const pilotos ={};
pilotos[0] = {id:0,nombre:"chofer1",idcliente:-1}
pilotos[1] = {id:1,nombre:"chofer2",idcliente:-1}
pilotos[2] = {id:2,nombre:"chofer3",idcliente:-1}
module.exports = {pilotos};