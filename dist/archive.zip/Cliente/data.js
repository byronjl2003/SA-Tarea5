const clientes = {};
clientes[0] = {id:0,nombre:"byron",idpiloto:-1};
clientes[1] = {id:1,nombre:"jose",idpiloto:-1};
clientes[2] = {id:2,nombre:"saul",idpiloto:-1};
module.exports  = {clientes};