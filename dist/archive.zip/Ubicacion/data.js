const ubicaciones = {};
ubicaciones[0] = {idpiloto:0,latitud:14.6349,longitud:90.5069};
ubicaciones[1] = {idpiloto:1,latitud:14.6349,longitud:90.5069};
ubicaciones[2] = {idpiloto:2,latitud:14.6349,longitud:90.5069};
module.exports = {ubicaciones};